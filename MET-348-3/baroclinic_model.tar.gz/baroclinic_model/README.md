# simple-atmospheric-models
Code for simple models of the atmosphere (and ocean)


<b>two_layer.f</b>
</br>Solves the two-layer baroclinic model from Holton (4th ed), should run with gfortran. Coded by a student as a very impressive project but needs to be recoded for clarity. Produces a binary output file, no plotting included (a GrADS control file is included in the 'grads' folder).

